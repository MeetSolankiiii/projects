<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./CSS/main.css">
    <script src="https://kit.fontawesome.com/5ac32e7bb4.js" crossorigin="anonymous"></script>

    <title>Burger | Home</title>
</head>

<body>
    <div class="container-lg">
        <div class="main-section">
            <?php
            include "INCLUDES/navigation.php";
            ?>

            <div class="container-lg">
                <div class="row">
                    <div class="col-md-6 hero-col">
                        <img src="./ASSETS/IMAGES/burger_big.png" alt="Big_Burger_Image" class="hero-section-burger">
                    </div>

                    <div class="col-md-6 hero-col">
                        <div class="container">
                            <div class="row">
                                <h1 class="hero-heading oswald-font">Enjoy Burgry Make Your Tummy Happy</h1>
                            </div>
                            <div class="row ">
                                <hr class="ms-2" id="bar">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia ut atque repudiandae
                                    ex aliquid praesentium accusamus exercitationem minima repellat. Ratione eaque
                                    deserunt cupiditate?</p>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="feature-icon">
                                        <i class="fa-solid fa-utensils" style="color: #FFD43B;"></i>
                                    </div>
                                    <div class="feature-text">
                                        Delicious
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="feature-icon">
                                        <i class="fa-solid fa-droplet" style="color: #FFD43B;"></i>
                                    </div>
                                    <div class="feature-text">
                                        Fresh
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="feature-icon">
                                        <i class="fa-solid fa-leaf" style="color: #FFD43B;"></i>
                                    </div>
                                    <div class="feature-text">
                                        Organic
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <button type="button" class="btn btn-warning">Learn More</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>



</body>

</html>