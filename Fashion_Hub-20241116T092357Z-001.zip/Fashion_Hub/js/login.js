var user = document.getElementById("username");
var pass =  document.getElementById("password");
var btn = document.querySelector(".login-button");

function checkvalidity() {
    if (user.value == "" || pass.value == "") {
        alert("Please provide Username & Password");
    } else {
        // Create an XMLHttpRequest object
        var xhttp = new XMLHttpRequest();
        
        // Define what happens on successful data submission
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                alert(this.responseText); // Display the response from login.php
            }
        };
        
        // Prepare and send the request
        xhttp.open("POST", "login.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("username=" + user.value + "&password=" + pass.value);
    }
}

btn.addEventListener("click", checkvalidity);
